
import React, { Component } from 'react';

import Sample from './Sample/Sample.Container';

class App extends Component{

   render(){

       console.log("App===");

      return(

         <div>

            <p>Working</p>

            <Sample />

         </div>

      );

   }

}

export default App;