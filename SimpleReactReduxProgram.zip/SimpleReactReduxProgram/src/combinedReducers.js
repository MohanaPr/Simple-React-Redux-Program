import { combineReducers } from 'redux';

import SampleReducer from './Sample/Sample.Reducer';

console.log("combineReducers===");

const rootReducer = combineReducers({

    SampleReducer:SampleReducer

});

export default rootReducer;
