import React from 'react';

class Sample extends React.Component{

onButtonClick(){

    console.log("clck===");

    this.props.actions.getValue("clicked");

}

render(){

    const {displayVal} = this.props;

    console.log("render===", displayVal);

    return(

        <div>Sample {displayVal}

            <br/> <button onClick={()=>this.onButtonClick()}>Submit</button>

        </div>

    )

}

}

export default Sample;