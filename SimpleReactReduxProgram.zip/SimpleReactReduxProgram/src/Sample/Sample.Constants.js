
const constants = {

    DISPLAY_VALUE:"DISPLAY_VALUE"

}

console.log("constants===");

export default constants;