import { connect } from "react-redux";

import { bindActionCreators } from "redux";

 

import Sample from './Sample';

import * as SampleActions from './Sample.Actions';

console.log("container===");

export default connect(

    (state) => ({

        displayVal:state.SampleReducer.displayVal

    }),

    (dispatch) => ({

        actions: bindActionCreators(SampleActions, dispatch)

    })

)(Sample);