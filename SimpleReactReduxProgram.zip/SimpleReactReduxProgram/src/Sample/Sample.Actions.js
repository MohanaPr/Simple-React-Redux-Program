import constants from './Sample.Constants';

export function getValue(displayVal){

    console.log("action===", constants);

    return{

        type:constants.DISPLAY_VALUE,

        displayVal

    };

}