
import constants from './Sample.Constants';

 

const initalState = {

    displayVal: "Hello"

};

 

function SampleReducer(state = initalState, action){

    console.log("reducer===", state.displayVal);

    switch (action.type) {

        case constants.DISPLAY_VALUE:

        return Object.assign({}, state, {

            displayVal : action.displayVal

        })

        default:

        return state;

    }

 

};

export default SampleReducer;